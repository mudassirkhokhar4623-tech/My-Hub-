# My Chatbot

A simple ChatGPT-style chatbot built with Python, Streamlit, and the Google Gemini API.

## Features
- Chat interface with message history
- The bot remembers earlier messages
- Streaming responses (text appears word by word)
- Sidebar with a system-prompt box and a "Clear chat" button

## Run locally

1. Install the packages:
   ```
   pip install -r requirements.txt
   ```
2. Copy `.env.example` to `.env` and paste your Gemini API key inside it.
3. Start the app:
   ```
   streamlit run app.py
   ```

## Deploy on Streamlit Community Cloud
1. Push this project to GitHub (do not upload `.env`).
2. On share.streamlit.io, click **New app** and pick this repo, branch `main`, file `app.py`.
3. Open **Advanced settings > Secrets** and add:
   ```
   GEMINI_API_KEY = "your-key-here"
   ```
4. Click **Deploy**.

## Tech
Python, Streamlit, google-genai
